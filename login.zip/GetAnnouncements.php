<?php

header('Access-control-Allow-Origin: *');
header('Content-Type: application/json');

/* $postdata = file_get_contents("php://input");
$request = json_decode($postdata);
//$emp_no = $request->emp_no;
$loginname = $request->username;
$loginpassword = $request->password; */

if(!isset($_POST)) die();
session_start();


$response=[];

$servername = "127.0.0.1";
$username = "root";
$password = ""; //Your User Password
$dbname = "test"; //Your Database Name


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


	$query = "Select * from Announcements";
//$query = "SELECT id FROM billing_details WHERE id= (SELECT MAX(id) FROM billing_details)";

$result = mysqli_query($conn,$query);
if (mysqli_num_rows($result)>0)
{
	// Fetch all

	 $response = mysqli_fetch_all($result,MYSQLI_ASSOC) ;
// Free result set
//mysqli_free_result($result);

	//$response = mysqli_fetch_array($result);
	

}else{
	
	$response = "NoAnnouncements";
}
/* if(mysqli_num_rows($result)>0){
	$response['status']='sucess';
	$response['username']=$loginname;
	$response['useruniqueid']=md5(uniqid());
	$_SESSION['useruniqueid']=$response['useruniqueid'];

}else{
	$response['status']= 'error';
} */

echo json_encode($response);

	

$conn->close(); 
//echo json_encode($result[0]);
?>