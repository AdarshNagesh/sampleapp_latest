<?php

header('Access-control-Allow-Origin: *');
header('Content-Type: application/json');

/* $postdata = file_get_contents("php://input");
$request = json_decode($postdata);
//$emp_no = $request->emp_no;
$loginname = $request->username;
$loginpassword = $request->password; */

if(!isset($_POST)) die();
session_start();


$response=[];
$response1=[];

$servername = "127.0.0.1";
$username = "root";
$password = ""; //Your User Password
$dbname = "test"; //Your Database Name


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);



	$query = "Select * from user";
//$query = "SELECT id FROM billing_details WHERE id= (SELECT MAX(id) FROM billing_details)";

$result = mysqli_query($conn,$query);
if (mysqli_num_rows($result)>0)
{
	// Fetch all

	 $response = mysqli_fetch_all($result,MYSQLI_ASSOC) ;
	 $i=0;
	 foreach($response as $res){
		 
		$brname = $res['Branch_Name'];
		$query2 = "Select BranchName from branch where BranchId='$brname'";
		$result2 = mysqli_query($conn,$query2);
		$value2=mysqli_fetch_object($result2);
		$brname2 = $value2->BranchName;
		$res['Branch_Name']= $brname2;
		 //echo json_encode($res);
		 $response1[$i]=$res;
		 
		 $i=$i+1;
	 }
	 
	
	// $response['Id']=$result[0];
// Free result set
//mysqli_free_result($result);

	//$response = mysqli_fetch_array($result);
	

}else{
	
	$response1 = "NoEmployees";
}
/* if(mysqli_num_rows($result)>0){
	$response['status']='sucess';
	$response['username']=$loginname;
	$response['useruniqueid']=md5(uniqid());
	$_SESSION['useruniqueid']=$response['useruniqueid'];

}else{
	$response['status']= 'error';
} */

echo json_encode($response1);

	

$conn->close(); 
//echo json_encode($result[0]);
?>