<?php

header('Access-control-Allow-Origin: *');
header('Content-Type: application/json');

$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
//$emp_no = $request->emp_no;

$Branch_Id = $request->Branch_Id;
$Branch_Name = $request->Branch_Name;


/* $loginpassword = $request->password; */
/* $Branch = (int)$Branch;
$Role = (int)$Role;
$Id = (int)$Id; */

$response=[];

$servername = "127.0.0.1";
$username = "root";
$password = ""; //Your User Password
$dbname = "test"; //Your Database Name


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);


	$query1 = "select * from branch where BranchId='$Branch_Id'";
//$query = "SELECT id FROM billing_details WHERE id= (SELECT MAX(id) FROM billing_details)";

$result1 = mysqli_query($conn,$query1);
if (mysqli_num_rows($result1)>0)
{
	$query2 = "UPDATE branch SET BranchName='$Branch_Name' where BranchId='$Branch_Id'";
	$result2 = mysqli_query($conn,$query2);
	if ($result2){
		$response['status']='success'; 
	}else{
		$response['status']= 'error';
	}
	 
	 
}else{
	//$query3 = "INSERT INTO branch (BranchId,BranchName) VALUES ('$Branch_Id','$Branch_Name')";
	$query3 = "INSERT INTO branch (BranchName) VALUES ('$Branch_Name')";
	$result3 = mysqli_query($conn,$query3);
	if ($result3){
		$response['status']='success';
	}else{
		$response['status']= 'error';
	}
	
	
}

	
	echo json_encode($response);
//echo json_encode($response);

/* if(mysqli_num_rows($result)>0){
	$response['status']='sucess';
	$response['username']=$loginname;
	$response['useruniqueid']=md5(uniqid());
	$_SESSION['useruniqueid']=$response['useruniqueid'];

}else{
	$response['status']= 'error';
} */



	

$conn->close(); 
//echo json_encode($result[0]);
?>