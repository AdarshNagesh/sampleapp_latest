import { Component, OnInit,ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgGrid } from 'angular2-grid';
import { TableComponent } from 'angular2-datagrid/src/app/demo';
import { BranchService } from '../branch';
import { NgDataGridModel } from 'angular2-datagrid/src/app/datagrid/ng-datagrid.model';

import { branch } from './branchModel';
import 'angular2-datagrid/src/app/utils/array.extensions';
import { ToasterContainerComponent,ToasterService,ToasterConfig ,Toast} from 'angular2-toaster';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css'],
  providers:[ToasterService,BranchService],
})
export class BranchComponent implements OnInit {

  table: NgDataGridModel<branch>;
  branches = [];
  isLoading : boolean;
  editingData = [];
  adminname:string;
  selectALL:boolean;

  public config1 : ToasterConfig = new ToasterConfig({
    positionClass: 'toast-top-center',
    timeout : 3000
    //tapToDismiss : true
  });

  constructor(private _Branchservice:BranchService, private _router: Router,vcr: ViewContainerRef,private toasterService: ToasterService) { 

    this.table = new NgDataGridModel<branch>([]);

    _Branchservice.getBranchDetails().subscribe(
      response => 
      {
        console.log(response);
        
        if(response === "NoAnnouncements"){

         // this.announcements = [{'Id':0,'Announcement':this.res}]

        }else{


          this.branches = response;
          console.log(this.branches);
          console.log(this.branches.length);
          var i;
          for (i = 0; i < this.branches.length; ++i) {
            console.log(this.branches[i]);
            this.table.items.push(new branch(this.branches[i].BranchId,this.branches[i].BranchName,true))
        }

              console.log(this.table);
          
        }
            
            /*   for (this.userId = 0; this.announcements.length; this.userId++) {
              this.table.items.push(new User(this.userId, `user ${this.userId}`,
                                          `Announcement${this.userId}`));
              } */ 
            },error=>alert(error),()=>this.isLoading=false




          );

  }

  ngOnInit() {

    if(!!localStorage.getItem("Login")){
      var login = JSON.parse(localStorage.getItem("Login"));
      console.log(login.isloggedin);
      if(login.isloggedin =='loggedin'){
       // this._router.navigate(['Announcements']);
       this.adminname = login.username;
    
      
     
      }
      
      //console.log(this.announcements.length);
      
    }else{
      this._router.navigate(['AdminLogin']);
    }




  }


  adminlogout(){
    
        localStorage.removeItem("Login");
        this._router.navigate(['']);
      }


      addBranchRecordPlugin() {
        this._Branchservice.getBranchDetails().subscribe(
          response => 
          {
            console.log(response);
            
            if(response === "NoAnnouncements"){
              let Branch_Id = 1;
              //userId = userId+1;
              console.log(Branch_Id);
              this.editingData[Branch_Id] = true;
              this.table.items.push(new branch(Branch_Id,"",false));
            }else{
              this.branches = response;
              console.log(this.branches.length);
              console.log(this.branches[this.branches.length-1].BranchId);
              var usrid =  parseInt(this.branches[this.branches.length-1].BranchId) +1;
              console.log(usrid);
              let userId = usrid
              //userId = userId+1;
              console.log(userId);
              this.editingData[userId] = true;
              this.table.items.push(new branch(usrid,"",false));
              
             /*   for (this.userId = 0; this.announcements.length; this.userId++) {
              this.table.items.push(new User(this.userId, `user ${this.userId}`,
                                          `Announcement${this.userId}`));
              } */

            }
             
          },error=>alert(error),()=>this.isLoading=false
    
    
    
    
        );
       
      
          
    }


    canceleditRecordPlugin(user){
      
          console.log(user.savedtoDB);
            if(user.savedtoDB === false){
              this.table.items.remove(user);
            }else{
      
              console.log(user.userId);
              this._Branchservice.getBranchDetails().subscribe(
                response => 
                {
                  console.log(response);
                  
                  if(response === "NoAnnouncements"){
          
                   // this.announcements = [{'Id':0,'Announcement':this.res}]
          
                  }else{
          
          
                    this.branches = response;
                    user.Branch_Name=this.branches[user.Branch_Id-1].BranchName;
          
          
                    
                  }
                      
                      /*   for (this.userId = 0; this.announcements.length; this.userId++) {
                        this.table.items.push(new User(this.userId, `user ${this.userId}`,
                                                    `Announcement${this.userId}`));
                        } */ 
                      },error=>alert(error),()=>this.isLoading=false
          
          
          
          
                    );
              this.editingData[user.Branch_Id] = !this.editingData[user.Branch_Id];
              console.log(this.editingData[user.Branch_Id]);
      
            }
            
            
      
          }



editRecordPlugin(user){
            
                  console.log(user.Branch_Id);
                  this.editingData[user.Branch_Id] = true;
                }



saveRecordPlugin(user){
                  console.log(user.userId);
                  
                  if(user.Branch_Name===""){
                    var toast: Toast = {
                      type: 'warning',
                      title: 'No Announcement entered',
                      showCloseButton: true};
                      this.toasterService.pop(toast);
                  }else{
                       //user.username = this.newann;
                  this._Branchservice.saveBranch({'Branch_Id':user.Branch_Id,'Branch_Name':user.Branch_Name}).subscribe(response => 
                    {
            
                     console.log(response);
                      if(response.status=='success'){
                        var toast: Toast = {
                          type: 'success',
                          title: 'Branch saved successfully',
                          showCloseButton: true};
                          this.toasterService.pop(toast);
                          user.savedtoDB = true;
                          this.editingData[user.Branch_Id] = false;

                          this._Branchservice.getBranchDetails().subscribe(
                            response => 
                            {
                              console.log(response);
                              
                              if(response === "NoAnnouncements"){
                      
                               // this.announcements = [{'Id':0,'Announcement':this.res}]
                      
                              }else{
                      
                      
                                this.branches = response;
                                console.log(this.branches);
                                console.log(this.branches.length);
                                console.log(this.branches[this.branches.length-1].BranchId);
                                user.Branch_Id = this.branches[this.branches.length-1].BranchId;
                                
                              }
                                  
                                  
                                  },error=>alert(error),()=>this.isLoading=false
                      
                      
                      
                      
                                );
                      



                      }else{
                       
                        var toast: Toast = {
                          type: 'error',
                          title: 'Branch save unsuccessfull',
                          showCloseButton: true};
                          this.toasterService.pop(toast);
                      }
                      
                      
                    },error=>alert(error),()=>this.isLoading=false
            
                  );
            
                  }
                 
                }


removeRecordPlugin(item) {
                  console.log(item);
                 
                    
            
                    this._Branchservice.deleteBranch({'Branch_Id':item.Branch_Id}).subscribe(response => 
                          {
                           console.log(response);
                            if(response.status=='success'){
                              var toast: Toast = {
                                type: 'success',
                                title: 'Branch deleted successfully',
                                showCloseButton: true};
                                this.toasterService.pop(toast);
                                this.table.items.remove(item);
                              
                            }else if (response.status=='error1') {

                              var toast: Toast = {
                                type: 'warning',
                                title: 'Atleast 1 employee is associated with Branch,Please deAssociate and try again',
                                showCloseButton: true};
                                this.toasterService.pop(toast);
                              
                            } else {
                              
                            
                             
                              var toast: Toast = {
                                type: 'error',
                                title: 'Branch not deleted',
                                showCloseButton: true};
                                this.toasterService.pop(toast);
                            }
                            
                            
                          },error=>alert(error),()=>this.isLoading=false
            
                        );
                     
                 
                }
            

removeAllselectedAnn() {
                  
                      var i;
                      var j=0;
                      var brname:string;
                      var del = [];
                      var len = this.table.itemsOnCurrentPage.length;
                      console.log(len);
                      for (i = 0; i < len; ++i) {
                        console.log(this.table.itemsOnCurrentPage[i].active);
                       if (this.table.itemsOnCurrentPage[i].active === true){
                         console.log(this.table.itemsOnCurrentPage[i].Branch_Name);
                         brname = "'"+this.table.itemsOnCurrentPage[i].Branch_Name+"'";
                         console.log(brname);
                        this._Branchservice.deleteBranch({'Branch_Id':this.table.itemsOnCurrentPage[i].Branch_Id}).subscribe(response => 
                          {
                           console.log(response);
                            if(response.status==='success'){
                              del[j] = "true";
                              //console.log(i);
                              //console.log(this.table.itemsOnCurrentPage[i-1].Branch_Name);
                              
                              this.table.items.remove(this.table.itemsOnCurrentPage[i-1]);
                              var toast: Toast = {
                                type: 'success',
                                title: 'Branch  deleted successfully',
                                showCloseButton: true};
                                this.toasterService.pop(toast);
                            }else{
                              del[j] = "false";
                              if(response.status==='error1'){
                                  console.log(brname);
                                 //console.log(this.table.itemsOnCurrentPage[i-1].Branch_Name) ;
                                 
                                 
                                var toast: Toast = {
                                  type: 'warning',
                                  title: 'Atleast 1 employee is associated with Branch,Please deAssociate and try again',
                                  showCloseButton: true};
                                  this.toasterService.pop(toast);

                              }
                              j=j+1;
                            }
                            
                            
                          },error=>alert(error),()=>this.isLoading=false
            
                        );
          
                        
                       }
                        
                    }
                    
          
                    console.log(this.selectALL);
                    this.selectALL = !this.selectALL;
                      
              }
          
            
changedActiveStatus(e: any) {
                
                console.log(this.selectALL);
                  this.selectALL = !this.selectALL;
                  console.log(this.selectALL);
                  if (this.selectALL) {
                    
                      this.table.itemsFiltered.forEach(user => user.active = e.target.checked);
                  } else {
                      this.table.itemsOnCurrentPage.forEach(user => user.active = e.target.checked);
                  }
          
                
              }
          
}
