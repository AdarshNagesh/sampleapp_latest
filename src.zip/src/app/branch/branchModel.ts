export class branch {
    active: boolean;

    constructor(public Branch_Id: number,
                public Branch_Name:string,
                public savedtoDB:boolean=false) {
        this.active = false;
    }
}