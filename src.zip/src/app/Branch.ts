import { Injectable } from '@angular/core';
import { Http,Headers,Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class BranchService {

  private GetBranchDetails_url="http://adarshashwini/BranchServices/GetBranchDetails.php";
  private GetRoleDetails_url="http://adarshashwini/BranchServices/GetRoleDetails.php";
  private GetBranchDetailsById_url="http://adarshashwini/BranchServices/GetBranchDetailsById.php";
  private delete_url="http://adarshashwini/BranchServices/DeleteBranch.php";
  private save_url="http://adarshashwini/BranchServices/SaveBranch.php";
  
    constructor(private _http:Http) { }
  
    getBranchDetailsById(Id){
      var headers1 = new Headers();
      
      var data1 = JSON.stringify(Id) ;
      console.log(data1);
      
      headers1.append('Content-Type','application/x-www-form-urlencoded;charset=utf-8');
       return this._http.post(this.GetBranchDetailsById_url,data1,{headers:headers1})
      .map((response:Response) => response.json()); 
      
      /* return this._http.get(this._url,{headers:headers1})
      .map((response:Response) => response.json()); */
      
      
    }


    getBranchDetails(){
      var headers1 = new Headers();
      
      
      
      headers1.append('Content-Type','application/x-www-form-urlencoded;charset=utf-8');
       
      
      return this._http.get(this.GetBranchDetails_url,{headers:headers1})
      .map((response:Response) => response.json());
      
      
    }

    getRoleDetails(){
      var headers1 = new Headers();
      
      
      
      headers1.append('Content-Type','application/x-www-form-urlencoded;charset=utf-8');
       
      
      return this._http.get(this.GetRoleDetails_url,{headers:headers1})
      .map((response:Response) => response.json());
      
      
    }


    deleteBranch(data){
      var headers1 = new Headers();
     
      var data1 = JSON.stringify(data) ;
      console.log(data);
      headers1.append('Content-Type','application/x-www-form-urlencoded;charset=utf-8');
      return this._http.post(this.delete_url,data1,{headers:headers1})
      .map((response:Response) => response.json());
      
     
      
    }


    saveBranch(data){
      var headers1 = new Headers();
     
      var data1 = JSON.stringify(data) ;
      console.log(data1);
      headers1.append('Content-Type','application/x-www-form-urlencoded;charset=utf-8');
      return this._http.post(this.save_url,data1,{headers:headers1})
      .map((response:Response) => response.json());
      
     
      
    }
    
    _errorHandler(Response: any){
      console.log(Response);
    }

}
