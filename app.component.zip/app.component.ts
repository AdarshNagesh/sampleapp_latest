import { Component,OnInit,ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { LoginServiceService } from './login-service.service';
import {AngularFireDatabase,FirebaseListObservable,FirebaseObjectObservable } from 'angularfire2/database-deprecated';
import { AngularFireAuth } from 'angularfire2/auth';
import { Observable } from 'rxjs/Observable';
import * as firebase from 'firebase/app';
import { ToasterContainerComponent,ToasterService,ToasterConfig ,Toast} from 'angular2-toaster';
import {items} from './ItemModel';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[LoginServiceService,AngularFireDatabase,AngularFireAuth,ToasterService],
  
})
export class AppComponent implements OnInit {
  title = 'app';
  public location = "";
  public showbanner:boolean;
  user:Observable<firebase.User>;
  items:FirebaseListObservable<any[]>;
  value:FirebaseObjectObservable<any>;
  adminname:string;
  msgval:string='';
  message;
  shownoti:boolean;
  constructor(private _router: Router,private afauth: AngularFireAuth,private afd:AngularFireDatabase,vcr: ViewContainerRef,private toasterService: ToasterService) { 
  

    if(!!localStorage.getItem("Login")){
      var login = JSON.parse(localStorage.getItem("Login"));
      console.log(login.isloggedin);
      if(login.isloggedin =='loggedin'){
       // this._router.navigate(['Announcements']);
       this.adminname = login.username;
      // console.log(this.adminname);
    /*  this.Announcements = [{announcement:"sdfdsfdvkjndjkfnsdkn",editable:"false"},{announcement:"dgfhfghgfhdsjfkjsdnfkjdsnfkjsdn",editable:"false"},
      
       ];  */
       /* this.announcements.forEach(
        function(ann){
        console.log(ann.Id);
        console.log(ann.Announcement);
        this.table.items.push(new User(1,"",""));

      }); */

      
     
      }
      
      //console.log(this.announcements.length);
      
    }






      
    
    
   
   /*  var toast: Toast = {
      type: 'success',
      title: 'New Announcement arrived',
      showCloseButton: true};
      this.toasterService.pop(toast); */
 }

 ngOnInit(){

  this.items = this.afd.list('/messages',{
    query:{
      limitToLast:50
    }
  });
  this.value = this.afd.object('/value');
  this.user = this.afauth.authState;
  this.location= this._router.url;
  this.showbanner=false;
  //console.log(this.items);

  this.items.forEach(item => {

    
    item.forEach(itm => {

     console.log(itm.username);
     if(itm.username === this.adminname){
        console.log(itm);
      var toast: Toast = {
        type: 'success',
        title: itm.message,
        timeout : 200000,
        showCloseButton: true,
        onHideCallback:(toast)=>{
          console.log('hi');
          this.items.remove(itm.$key).then(_=>console.log('deleted'));
        }};
        this.toasterService.pop(toast);
        this.shownoti = true;
        
     }
    
    
    })

    
  });
    
  
  

 }

 close(){

  console.log('hi');
 }

 routelocation(){

  this.location= this._router.url;
  console.log(this.location.toString);
  console.log("Hi");
  return this.location.toString;

 }

 login(){
   this.afauth.auth.signInAnonymously();
   console.log('loggedin');
 }

 logout(){
  this.afauth.auth.signOut();
}

Send(desc:string){
  this.items.push({message:desc,username:'AdarshNagesh'});
  this.msgval = "";
}
}
